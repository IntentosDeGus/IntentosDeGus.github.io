#Diseñe una lista donde el usuario defina el tamaño y los valores de cada elemento de una lista
#La app debe mostrar los valores de la lista actualisada
Nombres=[]
Tamaño=int(input("Tamaño de la lista) :"))
for i in range(Tamaño):
    print("Ingrese los datos del Aprendiz", i + 1)
    Nombre=input("Nombre del Aprendiz: ")
    Nombres.append(Nombre)
print("Los aprendices son :")

for i in range(Tamaño):
    print("-----------------------------")
    print("Nombres:",Nombres[i])
print("-----------------------------")
