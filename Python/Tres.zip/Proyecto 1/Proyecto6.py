#Ingresar la temperatura en °C y diga si el pasciente tiene fiebre con una temperatura mayor igual a 38 o tiene una temperatura normal

Celsius=float(input("Ingrese la Temperatura del pasciente en Grados Celsius"))

if Celsius>=38:
    print("El pasciente tiene Fiebre ")
else:
    print("El pasciente tiene una temperatura normal")