#Ingrese la edad y diga si es Mayor De Edad o Menor De Edad

Edad=int(input("Ingrese Su Edad"))

if Edad>=18:
    print("Usted Es Mayor De Edad")
else:
    print("Usted Es Menor De Edad")