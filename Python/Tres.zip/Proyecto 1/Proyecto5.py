#Algoritmo que ingrese un numero entero y diga si es par o no

Numero=int(input("Ingrese Un Numero Entero"))

if Numero %2==0:
    print("El Numero Ingresado Es Par")
else:
    print("El Numero Ingresado Es Impar")