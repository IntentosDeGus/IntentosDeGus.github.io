#App para ingresar un numero y que el valor de compra
#Si el valor de la compra es mayor a 100-00k
#Entonces calcule el descuento (7%) y total de la compras
Valor_Compra=float(input("Digite el valor de la compra"))

if Valor_Compra>100000:

    Descuento=Valor_Compra*0.7
    Total=Valor_Compra-Descuento    
    print("Subtotal:",Valor_Compra)
    print("Descuento:",Descuento)
    print("Total De Compra:",Total)
else:
    
    Descuento=Valor_Compra*0.0
    Total=Valor_Compra-Descuento
    print("Subtotal: ",Valor_Compra)
    print("Descuento: ",Descuento)
    print("Total De Compra:",Total)
