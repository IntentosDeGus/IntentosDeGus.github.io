#Algoritmo que ingrese un numero entero del 1 al 5 y diga si es primo o no

Numero=int(input("                              Ingrese Un Numero Entero ( 1-5 )   :   "))

if Numero == 1 :
    print("                                      El numero Ingresado Es Primo")
if Numero == 4 :
    print("                                      El numero Ingresado Es Primo")
else:
    print("                               El numero ingresado NO es Primo")
    print("            ---En caso de ingresar un numero erroneo de lo solicitado el algoritmo fallara---")