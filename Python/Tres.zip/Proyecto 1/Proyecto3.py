#algoritmo que ingrese una nota y si es mayor o igual a 3 entonces es APROBADO , Sino , REPROBADO

Nota=float(input("Ingrese Su Nota"))

if Nota>=3:
    print("Usted Esta Aprobado")
else:
    print("Usted Esta Reprobado")