#App que ingresar un numero , Diga si es un numero positivo o negativo

n=int(input("Digite Un Numero"))

if n>0:
    print("El Numero Indicado (",n,") Es Positivo")
else:
    print("El Numero Indicado (",n,") Es Negativo")