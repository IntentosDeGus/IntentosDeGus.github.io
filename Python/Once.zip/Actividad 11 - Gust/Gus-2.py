Marca=[]
Modelo=[]
Color=[]
Combustible=[]
Cilindraje=[]
Precio=[]

for i in range (1):
    Ma=input("Ingrese la Marca del Vehiculo")
    Marca.append(Ma)
    Mo=input("Ingrese el Modelo del Vehiculo")
    Modelo.append(Mo)
    Co=input("Ingrese el Color del Vehiculo")
    Color.append(Co)
    Com=input("Ingrese El Tipo De Combustible de su Vehiculo")
    Combustible.append(Com)
    Ci=input("Ingrese el Cilindraje del Vehiculo")
    Cilindraje.append(Ci)
    Pr=input("Ingrese el Precio del Vehiculo")
    Precio.append(Pr)

for i in range (1):
    print("Marca : ",Marca[i])
    print("Modelo : ",Modelo[i])
    print("Color : ",Color[i])
    print("Combustible : ",Combustible[i])
    print("Cilindraje : ",Cilindraje[i])
    print("Precio : ",Precio[i])
