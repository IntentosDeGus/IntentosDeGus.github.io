Titulo=[]
Genero=[]
Duracion=[]
Protagonista=[]
Precio=[]
Idioma=[]

for i in range (1):
    Ti=input("Ingrese el Titulo de la Pelicula")
    Titulo.append(Ti)
    Ge=input("Ingrese el Genero de la Pelicula")
    Genero.append(Ge)
    Du=input("Ingrese la Duracion de la Pelicula")
    Duracion.append(Du)
    Pro=input("Ingrese el Nombre del Protagonista")
    Protagonista.append(Pro)
    Pre=input("Ingrese el Precio de la Entrada")
    Precio.append(Pre)
    Id=input("Ingrese el Idioma en la Pelicula")
    Idioma.append(Id)
for i in range(1):
    print("Titulo : ",Titulo[i])
    print("Genero : ",Genero[i])
    print("Duracion : ",Duracion[i])
    print("Protagonista : ",Protagonista[i])
    print("Precio : ",Precio[i])
    print("Idioma : ",Idioma[i])
