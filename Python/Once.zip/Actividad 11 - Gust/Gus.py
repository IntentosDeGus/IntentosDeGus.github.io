Nombres=[]
Identificacion=[]
Correo=[]       
Telefono=[]
FechaNacimiento=[]
Direccion=[]
LugarNacimiento=[]

Tamaño=int(input("Ingrese el tamaño de la lista"))

for i in range (Tamaño):
    print("Ingrese los  datos del Aprendiz" , i+1  )
    No=input("Nombre de los Aprendices : ")
    Nombres.append(No)
    Id=input("Numero de Identificacion : ")
    Identificacion.append(Id)
    Co=input("Digite Su Correo : ")
    Correo.append(Co)
    Te=input("Digite su Numero de Telefono : " )
    Telefono.append(Te)
    Fe=input("Digite su Fecha de Nacimiento : ")
    FechaNacimiento.append(Fe)
    Di=input("Ingrese su Direccion : ")
    Direccion.append(Di)
    Lu=input("Ingrese su Lugar de Nacimiento : ")
    LugarNacimiento.append(Lu)
print("Los Aprendices Son : ")

for i in range(Tamaño):

    print("Nombres: ",Nombres[i])
    print("Identificacioin ",Identificacion[i])
    print("Correo : ",Correo[i])
    print("Celular : ",Telefono[i])
    print("Fecha de Nacimiento :",FechaNacimiento[1])
    print("Direccion : ",Direccion[i])
    print("Lugar De Nacimiento :",LugarNacimiento[i])
   