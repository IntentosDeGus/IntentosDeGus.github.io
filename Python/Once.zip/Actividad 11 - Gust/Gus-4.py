#Diseñe una app que ingrese los datosde un sistema de facturacion para ello se deben crear las siguientes listas vacias , Alimentarlas y mostrarlas
Lista=int(input("Ingrese el Numero de Facturas"))

Codigo_Factura=[]
Codigo_Cliente=[]
Nombre_Cliente=[]
Fecha_Factura=[]
Descripcion_Producto=[]
Precio_Unitario=[]
Cantidad_Producto=[]
Total=[]

#Total es igual Al Precio_Unitario*Cantidad_Producto
for i in range(Lista):

    print("=======================================================")
    Codigo_Fa=float(input("  Ingrese el Codigo de la Factura ||| "))
    Codigo_Factura.append(Codigo_Fa)

    Codigo_Cl=float(input("    Ingrese el Codigo del Cliente ||| "))
    Codigo_Cliente.append(Codigo_Cl)

    Nombre_Cl=input("    Ingrese el Nombre del Cliente ||| ")
    Nombre_Cliente.append(Nombre_Cl)

    Fecha_Fa=input("   Ingrese la Fecha de la Factura ||| ")
    Fecha_Factura.append(Fecha_Fa)

    Precio_Uni=float(input("       Ingrese el Precio Unitario ||| "))
    Precio_Unitario.append(Precio_Uni)

    Cantidad_Pro=int(input("Ingresse la Cantidad del Producto ||| "))
    Cantidad_Producto.append(Cantidad_Pro)

    Total.append(Cantidad_Pro*Precio_Uni)
    print("========================================================")

for i in range(Lista):
    print("========================================================")
    print("    Codigo De Factura : ",Codigo_Factura[i])
    print("   Codigo Del Cliente : ",Codigo_Cliente[i])
    print("   Nombre Del Cliente : ",Nombre_Cliente[i])
    print("     Fecha De Factura : ",Fecha_Factura[i])
    print("    Precio Por Unidad : ",Precio_Unitario[i])
    print("Cantidad De Productos : ",Cantidad_Producto[i])
    print("                Total : ",Total[i])
    print("========================================================")

