# Listas de lenguajes de Programación con 5 posiciones
Lenguajes=["Css" , "Java" , "Python" , "Mysql" , "Php"]

#Añadimos un elemento a la lista
Lenguajes.append("Html")

#Removemos un elemento por elemento
Lenguajes.remove("Mysql")

#Creamos el recorrido para crear la lista
for Programas in Lenguajes:
    print("          ",Programas)
    print("----------------------------")

#Definimos la longitud de la lista
Tamaño=len(Lenguajes)
print("El tamaño de la lista es:", Tamaño)
print("----------------------------")


