# Listas de libros con 7 posiciones
Libros=[" La Biblia" , " Citas del Presidente Mao Tse-Tung" , " Harry Potter" ," El Señor de los Anillos " , " El Alquimista" , " El Código da Vinci" , " Lo que el viento se llevo"]

#Añadimos un elemento a la lista
Libros.append(" El diario de Ana Frank")

#Eliminar un elemento por elemento
Libros.pop(2)

#Creamos el recorrido para crear la lista
for Lista in Libros:
    print(Lista)
    print("-----------------------------------")

#Definimos la longitud de la lista
Tamaño=len(Libros)
print("El tamaño de la lista es:", Tamaño)
print("-----------------------------------")

