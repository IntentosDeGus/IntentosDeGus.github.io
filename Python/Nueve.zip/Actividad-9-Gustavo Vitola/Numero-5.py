# Listas de colores con 8 posiciones
Colores=["Amarillo" , "Azul" , "Rojo" , "Morado" ,"Rosado", "Blanco" , "Negro" , "Verde"]

#Añadimos un elemento a la lista
Colores.append("Naranja")

#Removemos un elemento por posicion
Colores.pop(1)

#Creamos el recorrido para crear la lista
for Lista in Colores:
    print("          ",Lista)
    print("----------------------------")

#Definimos la longitud de la lista
Tamaño=len(Colores)
print("El tamaño de la lista es:", Tamaño)
print("----------------------------")


