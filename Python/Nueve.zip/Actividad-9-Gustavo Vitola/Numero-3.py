# Listas de plantas medicinales con 9 posiciones

Plantas=["Aloe Vera" , "Hipérico" , "Jengibre" , "Lavanda" , "  Mate" , "Oregano" , "Amapola" , "Caléndula" , "Limoncillo"]
Plantas.append("Diente de león")
for Medicinales in Plantas:
    print("        ",Medicinales)
    print("----------------------------")

Tamaño=len(Plantas)
print("El tamaño de la lista es:", Tamaño)
print("----------------------------")