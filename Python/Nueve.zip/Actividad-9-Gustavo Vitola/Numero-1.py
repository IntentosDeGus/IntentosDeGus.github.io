#Recorrer una lsita
Frutas = ["Frambuesa" , "Banana" , "Manzana"]

#Añadimos un elemento a la lista
Frutas.append("Mango")
Frutas.pop(1)
for Palabras in Frutas:
    print("         ",Palabras)
    print("----------------------------")

#Definimos la longitud de la lista
Tamaño=len(Frutas)
print("El tamaño de la lista es:", Tamaño)
print("----------------------------")

#Eliminar un elemento por posicion


