//Identifica las variables que voy a usar
var i 
//Al usar "Para" le decimos al algoritmo que inicie desde un numero - condicion para finalizar el proceso - suma de valores
for (i=0; i<=100; i++){
    document.write(i+"<br>")
}