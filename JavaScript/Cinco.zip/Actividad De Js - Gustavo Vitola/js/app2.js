// Especificar las variables a utilizar
var i 
//Especificar que la variable es igual a 1
i=1
while (i<=10) {
    document.write (i+"&nbsp;")
    i++
}